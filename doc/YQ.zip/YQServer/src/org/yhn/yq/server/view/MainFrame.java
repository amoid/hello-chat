package org.yhn.yq.server.view;
import org.yhn.yq.server.model.YQServer;

public class MainFrame {
	public static void main(String[] args) {
		new YQServer();
	}
}
